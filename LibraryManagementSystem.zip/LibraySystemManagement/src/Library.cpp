#include<iostream>
#include<limits>
using namespace std;
#include "../inc/Library.h"
#include "../inc/TransactionManager.h"

void Library::addBook()
{
    int bookID;
    std::string title;
    std::string author;
    std::string genre;

    cout<<"Enter BookID:"<<endl;
    cin>>bookID;
    cin.ignore();
    cout<<"Title is:"<<endl;
    getline(cin,title);
    cout<<"Author:"<<endl;
    getline(cin,author);
    cout<<"Genre is:"<<endl;
    getline(cin,genre);

    Book B(bookID,title,author,genre);
    books.push_back(B);
    cout<<"Book is successfully added:"<<endl;

}

void Library::deleteBook(int bookID)
{
    for(int i=0;i<books.size();i++)
    {
        if(books[i].getBookID()==bookID)
        {
            books.erase(books.begin()+i);
            cout<<"Book is deleted:"<<endl;
            return;
        }
    }
    cout<<"Book is not available"<<endl;
}

void Library::searchBook(int bookID)
{
    for(auto &bk:books)
    {
        if(bk.getBookID()==bookID)
        {
            bk.displayBookDetails();
            return;
        }
    }
    cout<<"Book not found"<<endl;
}

void Library::displayAllBooks()
{
    if(books.empty())
    {
      cout<<"Book is not available!!!!"<<endl;
      return;
    }
    for(auto &bk:books)
    {
        bk.displayBookDetails();
        cout<<"----------------"<<endl;
    }
}

void Library::addMember()
{
    int memberID;
    std::string name;
    string phone;

    cout<<"Enter memberID:"<<endl;
    cin>>memberID;
    cin.ignore();
    cout<<"Employee Name"<<endl;
    getline(cin,name);
    cout<<"Employee Phone number:"<<endl;
    getline(cin,phone);

    Member M(memberID,name,phone);
    members.push_back(M);
    cout<<"Member is successfully added:"<<endl;
}

void Library::deleteMember(int memberID)
{
    for(int i=0;i<members.size();i++)
    {
        if(members[i].getMemberID()==memberID)
        {
            members.erase(members.begin()+i);
            cout<<"Member is successfully deleted:"<<endl;
            return;
        }
    }
    cout<<"Member is not available:"<<endl;
}

void Library::searchMember(int memberID)
{
    for(auto &mb:members)
    {
        if(mb.getMemberID()==memberID)
        {
            mb.displayMemberDetails();
            return;
        }
    }
    cout<<"Member is not available:"<<endl;
}

void Library::displayAllMembers()
{
    if(members.empty())
    {
        cout<<"Member is not available:"<<endl;
        return;
    }
    for(auto &mb:members)
    {
        mb.displayMemberDetails();
        cout<<"_______________"<<endl;
    }
}

void Library::issueBook(int bookID,int memberID)
{
    Book *foundbook = nullptr;
    for(auto &b:books)
    {
        if(b.getBookID()==bookID)
        {
            foundbook =&b;
            break;
        }
    }
    if(foundbook == nullptr)
    {
        cout<<"Book not found"<<endl;
        return;
    }
    
    if(foundbook->getIssueStatus())
    {
        cout<<"Book is already issued:"<<endl;
        return;
    }
    Member* foundmember= nullptr;
    for(auto &m:members)
    {
        if(m.getMemberID()==memberID)
        {
        foundmember= &m;
        break;
        }
    }
    if(foundmember==nullptr)
    {
        cout<<"member not found"<<endl;
        return;
    }
    foundbook->issueBook();
    cout<<"Book is issued successfully to memberID"<<memberID<<endl;
    
    transactionmanager.addTransaction(bookID,memberID,"ISSUE");
}

void Library::returnBook(int bookID)
{
    Book *foundbook = nullptr;
    for(auto &b:books)
    {
        if(b.getBookID()==bookID)
        {
            foundbook=&b;
            break;
        }
    }
    if(foundbook==nullptr)
    {
        cout<<"Book not found"<<endl;
        return;
    }
    if(foundbook->getIssueStatus()==false)
    {
        cout<<"Book is not issued:"<<endl;
        return;
    }
    foundbook->returnBook();
    cout<<"Book returned succesfully"<<endl;
    
    transactionmanager.addTransaction(bookID,0,"RETURN");

}

void Library::showAllTransactions()
{
    transactionmanager.showAllTransactions();
}
