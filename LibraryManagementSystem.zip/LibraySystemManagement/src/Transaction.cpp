#include<iostream>
using namespace  std;

#include"../inc/Transaction.h"

Transaction::Transaction(int bid,int mid,std::string type,std::string date)
{
    bookID=bid;
    memberID=mid;
    this->type=type;
    this->date=date;
}

void Transaction::displayTransaction() const{

    cout<<"Transaction details:"<<endl;
    cout<<"BookID:"<< bookID<<endl;
    cout<<"MemberID:"<< memberID<<endl;
    cout<<"Type is:"<< type<<endl;
    cout<<"Date:"<< date<<endl;
}
