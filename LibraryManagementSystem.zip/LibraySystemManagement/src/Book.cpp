#include<iostream>
using namespace std;
#include"../inc/Book.h"

Book::Book::Book() : bookID(0), title(""), author(""), genre(""), isIssued(false) {}

Book::Book(int bookID,std::string title,std::string author,std::string genre)
{
    this->bookID =bookID;
    this->title = title;
    this->author = author;
    this->genre=genre;
}

void Book::displayBookDetails() const
{
    cout<<"Book details is:"<<endl;
    cout<<"BookID:"<<bookID<<endl;
    cout<<"Title of Book is :"<<title<<endl;
    cout<<"Author:"<<author<<endl;
    cout<<"Genre:"<<genre<<endl;
    cout<<"Book is issued or not:"<<isIssued<<endl;
}

bool Book::getIssueStatus() const
{
    return isIssued;
}
void Book::issueBook()
{
    if(isIssued == true)
    {
        cout<<"Book already issued"<<endl;
    }
    else
    {
      isIssued =true;
      cout<<"Book issued successfully"<<endl;
    }
}

void Book::returnBook()
{
    if(isIssued ==false)
    {
        cout<<"Book is not issued , cannot return"<<endl;
    }
    else
    {
       isIssued =false;
       cout<<"Book returned successfully"<<endl;
    }
}

int Book::getBookID()
{
    return bookID;
}