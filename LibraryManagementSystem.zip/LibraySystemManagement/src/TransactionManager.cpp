#include<iostream>
#include<ctime>
using namespace std;

#include"../inc/TransactionManager.h"
#include "../inc/Transaction.h"


void TransactionManager::addTransaction(int bookID,int memberID,std::string type)
{
    time_t now = time(0);
    tm* local_time = localtime(&now);
    int year = local_time->tm_year + 1900;
    int month = local_time->tm_mon + 1;
    int day = local_time->tm_mday;
    std::string date = to_string(day) + "/" + to_string(month) + "/" + to_string(year);

    Transaction t(bookID,memberID,type,date);
    transaction.push_back(t);
    cout<<"Transaction details are added successfully:"<<endl;

}

void TransactionManager::showAllTransactions()
{
    if(transaction.empty())
    {
        cout<<"Transaction not available"<<endl;
        return;
    }
    else{
        for(auto &t:transaction)
        {
            t.displayTransaction();
        }
    }
}