#include<iostream>
using namespace std;
#include"../inc/Member.h"

Member::Member():memberID(0),name(""),phone(""){ }
Member::Member(int id,std::string name,std::string  phone)
{
    memberID =id;
    this->name=name;
    this->phone =phone;
}
void Member::displayMemberDetails() const
{
    cout<<"Member Details is:"<<endl;
    cout<<"MemberID is:"<<memberID<<endl;
    cout<<"Employee name:"<<name<<endl;
    cout<<"Phone number is:"<<phone<<endl;
}
int Member::getMemberID()
{
    return memberID;
}
