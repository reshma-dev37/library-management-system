#include<iostream>
using namespace std;
#include"inc/Library.h"
#include"inc/TransactionManager.h"
int main()
{
    int choice;
    int bookID;
    int memberID;
    Library Lib;
    TransactionManager TM;
    while(true)
    {
    cout<<"Main Library Management System: "<<endl;
    cout<<"1.Add Book"<<endl;
    cout<<"2.Delete Book"<<endl;
    cout<<"3.Search Book"<<endl;
    cout<<"4.Display All Books"<<endl;
    cout<<"5.Add Member:"<<endl;
    cout<<"6.Issue Book"<<endl;
    cout<<"7.Return Book"<<endl;
    cout<<"8.Show All Transactions"<<endl;
    cout<<"9.Exit"<<endl;
    cout<<"Enter your choice"<<endl;
    cin>>choice;

    switch(choice)
    {
        case 1: 
                Lib.addBook();
                    break;
        case 2:
                cout<<"Enter BookID"<<endl;
                cin>>bookID;
                Lib.deleteBook(bookID);
                break;
        case 3:
               cout<<"Enter BookID"<<endl;
               cin>>bookID;
               Lib.searchBook(bookID);
               break;
        case 4:
              Lib.displayAllBooks();
              break;
        case 5:
              Lib.addMember();
              break;
        case 6:
              cout<<"Enter bookID and memberID"<<endl;
              cin>>bookID;
              cin>>memberID;
              Lib.issueBook(bookID,memberID);
              break;
        case 7:
              cout<<"Enter bookID"<<endl;
              cin>>bookID;
              Lib.returnBook(bookID);
              break;
        case 8:
             Lib.showAllTransactions();
             break;
        case 9:
             cout<<"Exiting!!!!!";
             return 0;
        default :
             cout<<"Invalid choice:"<<endl;


    }
    }

}