#ifndef BOOK_H
#define BOOK_H

#include<string>

class Book
{
 private:
 int bookID;
 std::string title;
 std::string author;
 std::string genre;
 bool isIssued;
 public:
 Book();
 Book(int bookID,std::string title,std::string author,std::string genre);
 void displayBookDetails() const;
 bool getIssueStatus() const;
 void issueBook();
 void returnBook();
 int getBookID();

};
#endif