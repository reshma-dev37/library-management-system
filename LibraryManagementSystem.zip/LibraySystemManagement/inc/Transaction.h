#ifndef TRANSACTION_H
#define TRANSACTION_H

#include<string>

class Transaction
{
    private:
    int bookID;
    int memberID;
    std::string type;
    std::string date;

    public:
    Transaction(int bid,int mid,std::string type,std::string date);
    void displayTransaction() const;

};
#endif