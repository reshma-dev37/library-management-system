#ifndef LIBRARY_H
#define LIBRARY_H

#include"../inc/Book.h"
#include"../inc/Member.h"
#include "../inc/TransactionManager.h"

#include<vector>
class Library
{

    private:
    std::vector<Book>books;
    std::vector<Member> members;
    TransactionManager transactionmanager;

    public:
    //book functions
    void addBook();
    void deleteBook(int bookID);
    void searchBook(int bookID);
    void displayAllBooks();
    //member functions
    void addMember();
    void deleteMember(int memberID);
    void searchMember(int memberID);
    void displayAllMembers();
    //issue/return operations
    void issueBook(int bookID,int memberID);
    void returnBook(int bookID);

    void showAllTransactions();


};
#endif