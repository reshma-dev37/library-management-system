#ifndef TRANSACTIONMANAGER_H
#define TRANSACTIONMANAGER_H

#include"../inc/Transaction.h"
#include<vector>
class TransactionManager
{
    private:
    std::vector<Transaction> transaction;
    public:
    void addTransaction(int bookID,int memberID,std::string type);
    void showAllTransactions();

};
#endif