#ifndef MEMBER_H
#define MEMBER_H

#include<string>
class Member
{
    private:
    int memberID;
    std::string name;
    std::string  phone;
    public:
    Member();
    Member(int id,std::string name,std::string phone);
    void displayMemberDetails() const;
    int getMemberID();

};
#endif